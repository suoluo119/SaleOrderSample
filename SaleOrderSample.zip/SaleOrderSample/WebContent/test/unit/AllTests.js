sap.ui.define([
	"SaleOrderSample/SaleOrderSample/test/unit/controller/SaleOrderList.controller"
], function () {
	"use strict";
});