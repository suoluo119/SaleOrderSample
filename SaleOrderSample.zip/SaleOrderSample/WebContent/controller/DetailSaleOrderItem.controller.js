sap.ui.define([
	'SaleOrderSample/SaleOrderSample/controller/BaseController',
	'sap/ui/model/json/JSONModel'
], function (BaseController, JSONModel) {
	"use strict";

	//set explored app's demo model on this sample
	//var oModel = new JSONModel(sap.ui.require.toUrl("sap/ui/demo/mock") + "/products.json");
	return BaseController.extend("SaleOrderSample.SaleOrderSample.controller.DetailSaleOrderItem", {
		onInit: function () {

			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

			//var oModel = new JSONModel();
			//oModel.loadData("./mockdata/products.json");

			//this.getView().setModel(oModel);
			//this.getView().bindElement("/SupplierCollection/0");

			var oRouter = this.getRouter();

		},

		onNavBack: function () {

			this.getRouter().navTo("DetailSaleOrder");

		},

		onSaveSaleOrderItem: function () {

			this.getRouter().navTo("CreateSaleOrder");

		}
	});
});