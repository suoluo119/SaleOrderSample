sap.ui.define([
	'SaleOrderSample/SaleOrderSample/controller/BaseController',
	'sap/ui/model/json/JSONModel'
], function (BaseController, JSONModel) {
	"use strict";

	//set explored app's demo model on this sample
	var oModel = new JSONModel(sap.ui.require.toUrl("sap/ui/demo/mock") + "/products.json");

	return BaseController.extend("SaleOrderSample.SaleOrderSample.controller.UpdateSaleOrder", {
		onInit: function () {

			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

			//var oModel = new JSONModel();
			//oModel.loadData("./mockdata/products.json");

			this.getView().setModel(oModel);
		},

		onNavBack: function () {

			this.getRouter().navTo("RouteSaleOrderList");

		},

		onCreateSalesOrderItem: function () {

			this.getRouter().navTo("CreateSaleOrderItem");

		},

		onUpdateSalesOrderItem: function () {

			this.getRouter().navTo("UpdateSaleOrderItem");

		}

	});
});