sap.ui.define([
	'SaleOrderSample/SaleOrderSample/controller/BaseController',
	'sap/ui/model/json/JSONModel',
	'sap/ui/core/Fragment'
], function (BaseController, JSONModel, Fragment) {
	"use strict";

	//set explored app's demo model on this sample
	var oModel = new JSONModel(sap.ui.require.toUrl("sap/ui/demo/mock") + "/products.json");

	return BaseController.extend("SaleOrderSample.SaleOrderSample.controller.SaleOrderList", {
		onInit: function () {

			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			//var oModel = new JSONModel();
			//oModel.loadData("./mockdata/products.json");

			//this.getView().setModel(oModel);

			var oRouter = this.getRouter();
			//oRouter.getRoute("appHome").attachMatched(this._onRouteMatched, this);
		},

		onSearch: function () {

			this.getView().setModel(oModel);
		},

		onCreateSalesOrder: function() {
			this.getRouter().navTo("CreateSaleOrder");

		},

		onSelectionDetail: function() {
			this.getRouter().navTo("DetailSaleOrder");

		},

		handleValueHelp : function() {
			//var sInputValue = this.byId("productInput").getValue(),
			//	oModel = this.getView().getModel(),
			//	aProducts = oModel.getProperty("/ProductCollection");

			if (!this._oValueHelpDialog) {
				this._oValueHelpDialog = sap.ui.xmlfragment(
					"SaleOrderSample.SaleOrderSample.view.OrgDialog",
					this
				);
				this.getView().addDependent(this._oValueHelpDialog);
			}

			this._oValueHelpDialog.open();
		}

	});
});