sap.ui.define([
	"sap/ui/demo/nav/controller/BaseController",
		"sap/ui/model/odata/v2/ODataModel",
		"sap/ui/model/json/JSONModel"
], function (BaseController,ODataModel,JSONModel) {
	"use strict";
	return BaseController.extend("sap.ui.demo.nav.controller.Home", {

		/*onDisplayNotFound : function () {
			// display the "notFound" target without changing the hash
			this.getRouter().getTargets().display("notFound", {
				fromTarget : "home"
			});
		},

		onNavToEmployees : function () {
			this.getRouter().navTo("employeeList");
		},*/
		
		onInit: function () {
			var oRouter = this.getRouter();
			oRouter.getRoute("appHome").attachMatched(this._onRouteMatched, this);
		},
		
		_onRouteMatched: function () {
			//var that = this;
			//var oModel = new ODataModel("/sap/opu/odata/sap/ZTEST_USR_SRV", true);
				
			//oModel.read("/", {
			//	async: false,
			//	success: function (oERP) {
			//			var oTable = that.getView().byId("employeeList");
			//			oModel = new JSONModel(oERP);
			//			oTable.setModel(oModel);
			//		},
			//	error: function (oError) {
			//	}
			//});
		},
		
		onNavToAddEmployee: function () {
			this.getRouter().navTo("addEmployee");
		},
		
		onListItemPressed : function(oEvent){
			var oItem, oCtx;
			var oModel = new ODataModel("/sap/opu/odata/sap/ZTEST_USR_SRV", true);
			oItem = oEvent.getSource();
			oCtx = oItem.getBindingContext();

			this.getRouter().navTo("employee",{
				employeeId : oCtx.getProperty("Usrid")
			});
		},
		
		handleValueHelpe: function () {

			var sInputValue = this.byId("productInput").getValue(),
				oModel = this.getView().getModel(),
				aProducts = oModel.getProperty("/ProductCollection");

			if (!this._oValueHelpDialog) {
				this._oValueHelpDialog = sap.ui.xmlfragment(
					"sap.ui.demo.nav.view.Dialog",
					this
				);
				this.getView().addDependent(this._oValueHelpDialog);
			}

			aProducts.forEach(function (oProduct) {
				oProduct.selected = (oProduct.Name === sInputValue);
			});
			oModel.setProperty("/ProductCollection", aProducts);

			this._oValueHelpDialog.open();
		}
	});
});
