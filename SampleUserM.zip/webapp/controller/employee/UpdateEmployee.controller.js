sap.ui.define([
	"sap/ui/demo/nav/controller/BaseController",
	"sap/ui/model/odata/v2/ODataModel"
], function (BaseController,ODataModel) {
	"use strict";
	var sUsrid = "";
	var sUsrname = "";
	var sUsraddr = "";
	
	return BaseController.extend("sap.ui.demo.nav.controller.employee.UpdateEmployee", {

		onInit: function () {
			var oRouter = this.getRouter();

			oRouter.getRoute("updateEmployee").attachMatched(this._onRouteMatched, this);
		},
		
		_onRouteMatched : function (oEvent) {
			var oArgs, oView;
			oArgs = oEvent.getParameter("arguments");
			oView = this.getView();
			sUsrid = oArgs.employeeId;
			oView.bindElement({
				//path : "/Employees(" + oArgs.employeeId + ")",
				path : "/ZUSERSet(Mandt='500',Usrid='" + oArgs.employeeId + "')",
				events : {
					change: this._onBindingChange.bind(this),
					dataRequested: function (oEvent) {
						oView.setBusy(true);
					},
					dataReceived: function (oEvent) {
						oView.setBusy(false);
					}
				}
			});
		},
		_onBindingChange : function (oEvent) {
			// No data for the binding
			if (!this.getView().getBindingContext()) {
				this.getRouter().getTargets().display("notFound");
			}
		},
		
		onNavToEmployeeList: function () {
			this.getRouter().navTo("appHome");
		},
		
		updateEmpolyee : function (oEvent) {
			var that = this;
			var oI18n = this.getView().getModel("i18n").getResourceBundle();
			//var oModel = sap.ui.getCore().getModel();
			var oModel = new ODataModel("/sap/opu/odata/sap/ZTEST_USR_SRV", true);
			sUsrname = this.getView().byId("employeeName").getValue();
			sUsraddr = this.getView().byId("employeeAddress").getValue();
			
			var oData = {};
				//oEntry.Mandt = "500";
				oData.Usrid = sUsrid;
				oData.Usrname = sUsrname;
				oData.Usraddr = sUsraddr;
			
			// commit creation
			oModel.update("/ZUSERSet(Mandt='500',Usrid='" + sUsrid + "')", oData, {
			    success: function() {
					var osuccessMsgDialog = new sap.m.Dialog({
						title: oI18n.getText("BoxSuccess"),
						type: "Message",
						state: "Success",
						content: [new sap.m.Label({
							text: oI18n.getText("AddEmployeeSuccessMsg")
						})]
					});
					osuccessMsgDialog.open();
					osuccessMsgDialog.addButton(new sap.m.Button({
						text: oI18n.getText("okBtn"),
						press: function () {
							osuccessMsgDialog.close();
							that.onNavToEmployeeList();
						}
					}));
			    },
			    error: function(oError) {
			        window.console.log("Error", oError);
			    }
			});
			
			
			//oModel.remove("/ZUSERSet(Mandt='500',Usrid='100')", {
			//	success: function() {
			//		sap.m.MessageToast.show("Deletion successful.");
			//	},
			//	error: function(oError) {
			//		window.console.log("Error", oError);
			//	}
			//});
		}
		
	});

});
