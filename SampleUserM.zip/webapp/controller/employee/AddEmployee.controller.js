sap.ui.define([
	"sap/ui/demo/nav/controller/BaseController",
	"sap/ui/model/odata/v2/ODataModel"
], function (BaseController,ODataModel) {
	"use strict";
	
	var sUsrid = "";
	var sUsrname = "";
	var sUsraddr = "";

	return BaseController.extend("sap.ui.demo.nav.controller.employee.AddEmployee", {

		onInit: function () {

		},
		
		onNavToEmployeeList: function () {
			this.getRouter().navTo("appHome");
		},
		
		saveEmployee: function () {
			var that = this;
			var oI18n = this.getView().getModel("i18n").getResourceBundle();
			//var oModel = sap.ui.getCore().getModel();
			var oModel = new ODataModel("/sap/opu/odata/sap/ZTEST_USR_SRV", true);
			sUsrid = this.getView().byId("employeeID").getValue();
			sUsrname = this.getView().byId("employeeName").getValue();
			sUsraddr = this.getView().byId("employeeAddress").getValue();
			
			var oEntity = {};
				//oEntry.Mandt = "500";
				oEntity.Usrid = sUsrid;
				oEntity.Usrname = sUsrname;
				oEntity.Usraddr = sUsraddr;

				oModel.create("/ZUSERSet", oEntity, {
					async: false,
					success: function (oData) {
					var osuccessMsgDialog = new sap.m.Dialog({
							title: oI18n.getText("BoxSuccess"),
							type: "Message",
							state: "Success",
							content: [new sap.m.Label({
								text: oI18n.getText("AddEmployeeSuccessMsg")
							})]
						});
						osuccessMsgDialog.open();
						osuccessMsgDialog.addButton(new sap.m.Button({
							text: oI18n.getText("okBtn"),
							press: function () {
								osuccessMsgDialog.close();
								that.onNavToEmployeeList();
							}
						}));
					},
					error: function (oError) {
						
					}
				});

		}
	});

});
